<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<!doctype html>
<html lang="en">

<head>
	<title>TandC</title>
	<?php include "includes/head.php" ?>
</head>


<body>


	<div class="container">

		<div class="row" id="colOne">
			<div class="col-12 col-md-8">

            <h1>Bastile Band</h1>
            <p>GDPR</p>

			</div>
			<div class="col-6 col-md-4">
                <img src="images/seal.png" alt=”privacy_photo” class="logo">
			</div>
		</div>
		<div class="row" id="colTwo">
			<div class="col-6 col-md-4">
                <p>First Policy</p>
                <p>
                If you sign up to this website and the website services, We may keep
                and analysis your private data about <b>YOU</b>. The data held will be <b>YOUR</b> username and password. 
                </p>
			</div>
			<div class="col-6 col-md-4">
                <p>Second Policy</p>
                <p>
                The information we gather is to help provide better services for <b>YOU</b>.
                We use <b>YOUR</b> data to validate the signing in process.
                </p>
			</div>
			<div class="col-6 col-md-4">
                <p>Thrid Policy</p>
                <p>
                <b>YOUR</b> data will be used and processed to help provide a more personalised website
                </p>
			</div>
		</div>
        <div class="row" id="colTwoo">
			<div class="col-6 col-md-4">
                <p>Forth Policy</p>
                <p>
                The data we hold about <b>YOU</b> will be kept safely and securely. If we do
                lose any data we will be <b>FINED</b> by the information commissioner. Furthermore, if <b>YOU DO NOT</b> want us to hold your information please delete your account via the account Settings<br>
                in your user profile settings.
                </p>
			</div>
			<div class="col-6 col-md-4">
                <p>Fifth Policy</p>
                <p>
                If <b>YOU</b> would want us to remove your data or if you have any other questions
                please email 2203162@uad.ac.uk Thank You
                </p>
			</div>
			<div class="col-6 col-md-4">
			</div>
		</div>	

        <div class="row" id="colThree">
            <div class="col-6">

            <p>Click <a href="register.php">HERE </a>to go back to register page</p><br> 

            </div>
            <div class="col-6">
            </div>

        </div>
	



		<div class="row">
			<div class="col-12">
				<?php include "includes/footer.php" ?>
			</div>
		</div>
	</div>
</body>

<footer>
<P>This website uses cookies for registered users. Click <a href="TandC.php">HERE</a> to see our term and conditions</P>
</footer>

</html>
</body>
</html>