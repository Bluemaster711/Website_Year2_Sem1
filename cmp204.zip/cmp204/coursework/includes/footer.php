<div id="extraInfo">
    <p>copyright &#169;</p>
    <p>version 2.0</P>
</div>