<?php

$servername = "";
$dbusername = "";
$dbpassword = "";
$dbname = "";


$enterMatrix = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);

// //failed
// if (!$enterMatrix){
//     die("You were not able to connect: " . mysqli_connect_errno());
// }else{
//     echo "Database connected";
// }


//mysqli_close($enterMartix);

?>
