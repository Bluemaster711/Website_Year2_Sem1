<ul id="panel">
    <li><a href="index.php" class="bluetxt">Home</a></li>
    <li><a href="tourInfo.php" class="bluetxt">Tour Info</a></li>
    <li><a href="discography.php" class="bluetxt">Discography</a></li>
    <!--only show if authenticated user is signed in-->
    <li><a href="userProfile.php" class="bluetxt">User Profile</a></li>
    <li><a href="logout.php" class="bluetxt">Logout</a></li>
</ul> 