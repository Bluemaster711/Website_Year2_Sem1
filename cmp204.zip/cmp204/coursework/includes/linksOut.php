
<ul id="panel">
    <li><a href="index.php" class="bluetxt">Home</a></li>
    <li><a href="tourInfo.php" class="bluetxt">Tour Info</a></li>
    <li><a href="discography.php" class="bluetxt">Discography</a></li>
    <!--only show if user is not signed in-->
    <li><a href="register.php" class="bluetxt">Register</a></li>
    <li><a href="login.php" class="bluetxt">Login</a></li>

</ul> 

