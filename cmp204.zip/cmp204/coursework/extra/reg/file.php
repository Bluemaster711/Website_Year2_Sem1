<!doctype html>

<html lang="en">
<head>
	<meta charset="utf-8">
	<title>CMP204 Unit Two Coursework Template</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<link rel="stylesheet" href="css/style.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="javascript/script.js"></script>   

</head>
<body>
    <header>
        <nav>
        <?php
session_start();
if (!empty($_SESSION["id"])) {
  include_once "includes/includes.php";
}else{
  include_once "includes/links.php";
}
?>
        </nav>
    </header>

    <div class="site_name">
        <h1>Register</h1>
    </div>

    <div class="row">
    <div class="col-md-6 login">
      <h2>Here to SIGN UP</h2>
      

      <div class="form" >
          <form action="processRegistration.php" method="post">
          <label> EMAIL</label>
          <input type="text" name="email" class="form-control">
  
          <label> USERNAME</label>
          <input type="text" name="name" class="form-control">
     
          <label> PASSWORD</label>
          <input type="password" name="password" class="form-control">
    
          <input type="submit" name="submit">
        </form>
      </div>
      <a href="login.php">Already have and accout? Go to login</a>

    </div>
  </div>
    <footer>

<!------GDPR --------->
        <div id="flip">Click to show/hide General Data Protection Regulation</div>
            <div id="panel">
        <div class=gdpr>
        <h4>Data protection principles</h4>
                <div class=row>
                    <div class=col-md-6>
                        <p>Information need to be: </p>
                        <ul>
                            <li>Used fairly, lawfully and transparently</li>
                            <li>Used for specified, explicit purposes</li>
                            <li>Used in an adequate way, relevant and limited to only what is necessary</li>
                            <li>Accurate and, where necessary, kept up to date</li>
                            <li>Kept for no longer than is necessary</li>
                            <li>Handled in a way that ensures appropriate security, including protection against unlawful or unauthorised processing, access, loss, destruction or damage</li>
                        </ul>
                        <hr>
                    </div>

                    <div class=col-md-6>
                        <p>You have right to: </p>
                        <ul>
                            <li>Be informed about how your data is being used</li>
                            <li>Access personal data</li>
                            <li>Have incorrect data updated</li>
                            <li>Have data erased</li>
                            <li>Stop or restrict the processing of your data</li>
                            <li>Data portability (allowing you to get and reuse your data for different services)</li>
                            <li>Object to how your data is processed in certain circumstances</li>
                        </ul>
                        <hr>
                    </div>

                    <a href="https://www.gov.uk/data-protection">HERE FOR MORE INFO!</a>

            </div>
        </div>
    <!------PANEL SLIDE DOWN --------->


</footer>
<?php include("processRegistration.php");?>

</body>
</html>